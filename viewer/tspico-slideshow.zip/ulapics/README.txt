Copy ulapics to the TS-Pico SD card.
SAVE "tpi:cd ulapics"
LOAD "tpi:ulavpico.tap"
LOAD ""
RUN

Add data-only image TAPs exported with Include ULAVIEW unchecked.
Edit line 9510 to list their filenames, followed by "*".
Line 70 sets T (seconds, 0=wait key) and LP (1=repeat).
Hardware playback has not yet been verified.
