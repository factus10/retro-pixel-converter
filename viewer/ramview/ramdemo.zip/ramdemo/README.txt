Load ramdemo.tap in this directory, then RUN. It preloads two frames
to TS-Pico SRAM and loops with wipes. Both frames have identical
palettes and attributes, so after the first black reveal they wipe
directly between images. SHIFT-BREAK restores black-on-white BASIC.
Uses SRAM region 0, chunks 0-3; its previous contents are replaced.
Uses stock MEMDOCK; physical playback is not yet verified.
